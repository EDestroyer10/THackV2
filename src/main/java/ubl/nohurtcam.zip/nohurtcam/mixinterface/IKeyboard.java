package ubl.nohurtcam.mixinterface;

public interface IKeyboard
{
	void cwOnChar(long window, int codePoint, int modifiers);
}
