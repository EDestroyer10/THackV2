package ubl.nohurtcam.gui.screen.mainmenu;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;

public class MainMenu extends Screen {

    public MainMenu() {
        super(Text.translatable("narrator.screen.title"));
    }

}


