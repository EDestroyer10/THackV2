package ubl.nohurtcam.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import ubl.nohurtcam.utils.TimerUtil;

import java.awt.Color;
import java.util.ArrayList;

public class Gui
{
	public void mouseClicked(double mouseX, double mouseY, int button)
	{

	}

	public void mouseReleased(double mouseX, double mouseY, int button)
	{

	}

	public void mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY)
	{

	}

	public void mouseScrolled(double mouseX, double mouseY, double amount)
	{

	}

	public void keyPressed(int keyCode, int scanCode, int modifiers)
	{

	}

	public void keyReleased(int keyCode, int scanCode, int modifiers)
	{

	}
}
