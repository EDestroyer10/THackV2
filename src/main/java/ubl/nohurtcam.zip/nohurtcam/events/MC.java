package ubl.nohurtcam.events;

import net.minecraft.client.MinecraftClient;

public interface MC {
    MinecraftClient mc = MinecraftClient.getInstance();
    //THIS WAS EXTREMELY DIFFICULT GUYS HARDEST INTERFACE EVER
}