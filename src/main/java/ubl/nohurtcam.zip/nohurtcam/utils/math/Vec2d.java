package ubl.nohurtcam.utils.math;

public class Vec2d
{
	public final double x, y;

	public Vec2d(double x, double y)
	{
		this.x = x;
		this.y = y;
	}
}