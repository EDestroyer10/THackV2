package ubl.nohurtcam.features;

import ubl.nohurtcam.feature.Feature;

public class NoHurtCamFeature extends Feature {

    public NoHurtCamFeature() {
        super("noViewBob", "a");
    }


    public void onEnable() {

    }

    public void onDisable() {

    }
}