package ubl.nohurtcam.features;

import ubl.nohurtcam.feature.Feature;

public class NoOverlayFeature extends Feature
{
	public NoOverlayFeature()
	{
		super("NoOverlay", "cancels lava, water, powdersnow overlay");
	}
}
