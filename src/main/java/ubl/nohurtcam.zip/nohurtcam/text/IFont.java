package ubl.nohurtcam.text;

public class IFont {

	public static GlyphPageFontRenderer COMFORTAA = GlyphPageFontRenderer.createFromID("/assets/optimizer/lang/font/comfortaa.ttf",
            19, false, false, false);

}