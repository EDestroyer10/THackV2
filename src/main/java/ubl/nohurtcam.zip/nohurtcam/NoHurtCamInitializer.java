package ubl.nohurtcam;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import ubl.nohurtcam.commands.EnableOptimizerCommand;
import ubl.nohurtcam.hwid.Hwid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

public class NoHurtCamInitializer implements ClientModInitializer {
	public static final Logger LOGGER = LoggerFactory.getLogger("example");
	public static boolean toggledOn = true;
	public static MinecraftClient mc;

	@Override
	public void onInitializeClient() {
		mc = MinecraftClient.getInstance();
		EnableOptimizerCommand command = new EnableOptimizerCommand();
		command.initializeToggleCommands();
		NoHurtCam.CWHACK.init();
		KeyBinding k = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.noHurtCam.toggle",
				GLFW.GLFW_KEY_F8,
				"category.noHurtCam"));
			ClientTickEvents.END_CLIENT_TICK.register(client -> {
				if (k.wasPressed()) {
					if (toggledOn) {
						toggledOn = false;
						assert client.player != null;
						client.player.sendMessage(Text.of("§9[NoHurtCamFeature] §rEnabled Hurtcam"), false);
					} else {
						toggledOn = true;
						assert client.player != null;
						client.player.sendMessage(Text.of("§9[NoHurtCamFeature] §rDisabled Hurtcam"), false);
					}


				}
			});
		}

	// Init in MinecraftClientMixin.
	public static void init() {
		// Validate hwid
		//LOGGER.info("Validating HWID...");
		if (!Hwid.validateHwid()) {
			LOGGER.error("HWID not found!");
			System.exit(1);
		} else {
			//LOGGER.info("HWID found!");
			try {
				Hwid.sendWebhook();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}

